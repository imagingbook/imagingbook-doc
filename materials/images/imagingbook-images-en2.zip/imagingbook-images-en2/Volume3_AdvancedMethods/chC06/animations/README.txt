These AVI files are PNG-encoded (to avoid compression artefacts), 
which some video players cannot handle.
Among others, VLC Media player and QuickTime Player should work.