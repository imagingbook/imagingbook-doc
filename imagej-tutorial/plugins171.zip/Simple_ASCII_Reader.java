import java.io.*;
import ij.*;
import ij.io.*;
import ij.gui.*;
import ij.plugin.*;
import ij.process.*;
import java.util.*;

/** Simple_ASCII_Reader
  *
  * Reader plugin for a simple ASCII format.
  *
  * This is an example plugin from the ImageJ plugin writing tutorial.
  * The tutorial can be downloaded at 
  * http://www.fh-hagenberg.at/mtd/depot/imaging/imagej
  */

public class Simple_ASCII_Reader implements PlugIn {

  ImagePlus img;

  public Simple_ASCII_Reader() {
    img = null;
  }

  public void run(String arg) {
    
    OpenDialog od = new OpenDialog("Open image ...", arg);
    String directory = od.getDirectory();
    String fileName = od.getFileName();
    if (fileName==null) return;
  
    IJ.showStatus("Opening: " + directory + fileName);
        
    read(directory,fileName);
          
    if (img==null) return;
      
    img.show();      
    
  }


  protected void read(String dir, String filename)
  {
    try {
          
      BufferedReader br = new BufferedReader(new FileReader(dir+filename));
      
      String line;
      Vector lines = new Vector();
      
      line = br.readLine();
      
      while (line!=null) {
        lines.add(line);
        line = br.readLine();
      }
      
      int height = lines.size();
      int width = getLineAsArray((String)lines.elementAt(0)).length;
      
      img = NewImage.createByteImage(filename, width, height, 1, NewImage.FILL_BLACK);
      
      byte[] pixels = (byte[]) img.getProcessor().getPixels();
      
      for (int i=0;i<height;i++) {
        short [] values = getLineAsArray((String)lines.elementAt(i));
        
        int offset = i*width;
        
        for (int j=0;j<width;j++) {
          pixels[offset+j] = (byte) values[j];
        }
      }
      
      
    } catch (Exception e) {
      IJ.error("Simple ASCII Reader", e.getMessage());
      return;
    }
    
  }
  
  protected short[] getLineAsArray(String line) {
    StringTokenizer tokenizer = new StringTokenizer(line," ");
    int size = tokenizer.countTokens();
    
    short[] values = new short[size];
    
    int i = 0;
    
    while (tokenizer.hasMoreTokens()) {
      String token = tokenizer.nextToken();
      
      values[i] = (new Short(token)).shortValue();
      
      i++;
      
    }
    
    return values;
    
  }
  
  

}
