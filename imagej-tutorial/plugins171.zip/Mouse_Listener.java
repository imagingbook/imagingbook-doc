import ij.*;
import ij.plugin.filter.PlugInFilter;
import ij.process.*; 
import ij.gui.*;
import java.awt.event.*;

/** Mouse_Listener
  *
  * Plugin for listening to mouse clicks in image window.
  *
  * This is an example plugin from the ImageJ plugin writing tutorial.
  * The tutorial can be downloaded at 
  * http://www.fh-hagenberg.at/mtd/depot/imaging/imagej
  */


public class Mouse_Listener implements PlugInFilter, MouseListener {

    ImagePlus img;
    ImageCanvas canvas;

    public int setup(String arg, ImagePlus img) {
        this.img = img;
        return DOES_ALL+NO_CHANGES;
    }

    public void run(ImageProcessor ip) {
    	// get window and canvas
        ImageWindow win = img.getWindow();
        canvas = win.getCanvas();
        // add this class as listener
        canvas.addMouseListener(this);
    }

	// method is called when mouse is clicked
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        int offscreenX = canvas.offScreenX(x);
        int offscreenY = canvas.offScreenY(y);
        IJ.showMessage("mousePressed: "+offscreenX+","+offscreenY);
    }

    public void mousePressed(MouseEvent e) {}

    public void mouseReleased(MouseEvent e) {}

    public void mouseEntered(MouseEvent e) {}

    public void mouseExited(MouseEvent e) {}

}
