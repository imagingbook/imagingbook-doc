import java.io.*;
import ij.*;
import ij.io.*;
import ij.gui.*;
import ij.plugin.filter.*;
import ij.process.*;
import java.util.*;


/** Simple_ASCII_Writer
  *
  * Writer plugin for a simple ASCII format.
  *
  * This is an example plugin from the ImageJ plugin writing tutorial.
  * The tutorial can be downloaded at 
  * http://www.fh-hagenberg.at/mtd/depot/imaging/imagej
  */

public class Simple_ASCII_Writer implements PlugInFilter {

  ImagePlus img;
  ImageProcessor ip;

  public Simple_ASCII_Writer() {
    img = null;
    ip = null;
  }

  public int setup(String arg, ImagePlus imp) {
      img = imp;
      return DOES_8G;
    }

  public void run(ImageProcessor ip) {
    
    SaveDialog sd = new SaveDialog("Save image ...", "image",".txt");
    String directory = sd.getDirectory();
    String fileName = sd.getFileName();
    if (fileName==null) return;
  
    IJ.showStatus("Saving: " + directory + fileName);
    
    this.ip = ip;
        
    write(directory, fileName);
          
      
    
  }


  protected void write(String dir, String filename)
  {
    try {
          
      BufferedWriter bw = new BufferedWriter(new FileWriter(dir+filename));

      byte[] pixels = (byte[])ip.getPixels();

      int offset, pos;

      for (int j=0;j<img.getHeight();j++) {
        offset = j*img.getWidth();
        for (int i=0;i<img.getWidth();i++) {
          pos = offset = i;
          bw.write(new Integer(pixels[pos] & 0xff).toString());
          if (i<img.getWidth()-1) bw.write(" ");
        }
        if (j<img.getHeight()-1) bw.write("\n");
      }

      bw.close();

    } catch (Exception e) {
      IJ.error("Simple ASCII Writer", e.getMessage());
      return;
    }
    
  }


}
